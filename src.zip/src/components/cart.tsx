import { YStack } from "tamagui";

export const Cart: React.FC<any> = () => {
    return (<YStack></YStack>)
};